create view VW_mineracao as
select dayname(`pizzaria`.`pedidos`.`data_pedido`)                                            AS `dia`,
       case
           when hour(`pizzaria`.`pedidos`.`hora_pedido`) < 20 then 'Inicio'
           when hour(`pizzaria`.`pedidos`.`hora_pedido`) between 20 and 22 then 'Pico'
           when hour(`pizzaria`.`pedidos`.`hora_pedido`) > 22 then 'Final' end                AS `periodo`,
       `pizzaria`.`pedidos`.`tipo_entrega`                                                    AS `tipo_entrega`,
       case when 'valor_borda' > 0 then 'Borda sim' else 'Borda não' end                      AS `borda`,
       case when 'valor_refrigerante' > 0 then 'Refrigerante sim' else 'Refrigerante não' end AS `refrigerante`,
       case
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 10 and `pizzaria`.`pedidos`.`valor_pizza` < 14) then 'VP 10-14'
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 14 and `pizzaria`.`pedidos`.`valor_pizza` < 18) then 'VP 14-18'
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 18 and `pizzaria`.`pedidos`.`valor_pizza` < 22) then 'VP 18-22'
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 22 and `pizzaria`.`pedidos`.`valor_pizza` < 26) then 'VP 22-26'
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 26 and `pizzaria`.`pedidos`.`valor_pizza` < 30) then 'VP 26-30'
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 30 and `pizzaria`.`pedidos`.`valor_pizza` < 34) then 'VP 30-34'
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 34 and `pizzaria`.`pedidos`.`valor_pizza` < 38) then 'VP 34-38'
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 38 and `pizzaria`.`pedidos`.`valor_pizza` < 42) then 'VP 38-42'
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 42 and `pizzaria`.`pedidos`.`valor_pizza` < 46) then 'VP 42-46'
           when (`pizzaria`.`pedidos`.`valor_pizza` >= 46 and `pizzaria`.`pedidos`.`valor_pizza` <= 50) then 'VP 46-50'
           else NULL end                                                                      AS `valor_pizza`,
       case
           when time_to_sec(`pizzaria`.`pedidos`.`tempo`) / 60 between 10 and 21.24 then 'TP 10-21.24'
           when time_to_sec(`pizzaria`.`pedidos`.`tempo`) / 60 between 21.25 and 32.4 then 'TP 21.25-32.4'
           when time_to_sec(`pizzaria`.`pedidos`.`tempo`) / 60 between 32.5 and 43.74 then 'TP 32.5-43.74'
           when time_to_sec(`pizzaria`.`pedidos`.`tempo`) / 60 between 43.75 and 55 then 'TP 43.75-55'
           else NULL end                                                                      AS `tempo`
from `pizzaria`.`pedidos`
where year(`pizzaria`.`pedidos`.`data_pedido`) <> 2015;

