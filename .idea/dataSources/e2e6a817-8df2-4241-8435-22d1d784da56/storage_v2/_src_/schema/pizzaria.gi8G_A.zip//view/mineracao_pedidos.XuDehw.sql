create view mineracao_pedidos as
select `pizzaria`.`pedidos`.`data_pedido`                                                AS `data_pedido`,
       `pizzaria`.`pedidos`.`hora_pedido`                                                AS `hora_pedido`,
       `pizzaria`.`pedidos`.`tipo_entrega`                                               AS `tipo_entrega`,
       `pizzaria`.`pedidos`.`valor_pizza`                                                AS `valor_pizza`,
       `pizzaria`.`pedidos`.`valor_borda`                                                AS `valor_borda`,
       `pizzaria`.`pedidos`.`valor_refrigerante`                                         AS `valor_refrigerante`,
       `pizzaria`.`pedidos`.`valor_entrega`                                              AS `valor_entrega`,
       `pizzaria`.`pedidos`.`hora_entrega`                                               AS `hora_entrega`,
       `pizzaria`.`pedidos`.`valor_pizza` + `pizzaria`.`pedidos`.`valor_borda`           AS `valor_total`,
       timediff(`pizzaria`.`pedidos`.`hora_entrega`, `pizzaria`.`pedidos`.`hora_pedido`) AS `tempo`
from `pizzaria`.`pedidos`;

