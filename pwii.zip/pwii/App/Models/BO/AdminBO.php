<?php
    namespace App\Models\BO;
    
    use App\Models\DAO\AdminDAO;
    use App\Models\Entidades\Admin;
    
    use Exception;
    
    class AdminBO {
        public function instanciaDAO(){
            return new AdminDAO();
        }
        
        public function inserir(Admin $admin){
            $dao = $this->instanciaDAO();
                       
            if($admin->getNome() == null || trim($admin->getNome()) == ''){
                return false;
            }
            
            if($admin->getEmail() == null || trim($admin->getEmail()) == ''){
                return false;
            }
            
            if($admin->getSenha() == null || trim($admin->getSenha()) == ''){
                return false;
            }
                        
            return $dao->inserir($admin);
        }

        public function listar($pagina, $quanRegistro, $busca){
            $dao = $this->instanciaDAO();
                       
            return $dao->listar($pagina, $quanRegistro, $busca);
        }

        public function selecionar($codigo){
            $dao = $this->instanciaDAO();
            
            if($codigo == null || trim($codigo) == '' || !is_numeric($codigo)){
                return false;
            }
            
            return $dao->selecionar($codigo);            
        }

        public function logar($email, $senha){
            $dao = $this->instanciaDAO();
            
            if($email == null || trim($email) == ''){
                return false;
            }
            
            if($senha == null || trim($senha) == ''){
                return false;
            }
            
            return $dao->logar($email, $senha);
        }

        public function alterar($dados){
            $dao = $this->instanciaDAO();
            
            return $dao->alterar($dados);
        }

        public function quantidadeTotal($busca){
            $dao = $this->instanciaDAO();
            
            return $dao->quantidadeAdmins($busca);
        }
    }
?>
