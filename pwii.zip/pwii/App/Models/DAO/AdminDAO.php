<?php
    namespace App\Models\DAO;

    use App\Models\Entidades\Admin;

    class AdminDAO extends BaseDAO{
        
        function logar($email, $senha) {
            $conexao = $this->conectar();

            $resultado = $conexao->query("SELECT * FROM admin WHERE email = '$email' and senha = md5('$senha')");

            if ($resultado){

                if($registro = $resultado->fetch_array(MYSQLI_ASSOC)){
                    $item = new Admin();
                    
                    $item->setCodigo($registro["codigo"]);
                    $item->setNome($registro["nome"]);
                    $item->setEmail($registro["email"]);
                    
                    return $item;
                }
            }

            $conexao->close();

            return null; 
        }
                
        public function inserir(Admin $admin) {

            try {
                $conexao = $this->conectar();
                
                $sql = sprintf("INSERT INTO `admin` (`nome`, `email`, `senha`) VALUES ('%s', '%s', md5('%s'))",
                        $admin->getNome(), $admin->getEmail(), $admin->getSenha());

                $conexao->query($sql);

                $admin->setCodigo("$conexao->insert_id");

                if($admin->getCodigo() > 0){
                    $conexao->close();
                    return $admin;
                } else {
                    $conexao->close();
                    return false;
                }
            }catch (\Exception $e){
                throw new Exception();
            }
        }
        
        public function alterar($dados) {
            $admin = $this->selecionar($dados["codigo"]);
            $dados_alt = [
                "codigo" => $admin->getCodigo(),
                "nome" => !isset($dados['nome']) ? $admin->getNome() : $dados['nome'],
                "email" => !isset($dados['email']) ? $admin->getEmail() : $dados['email'],
                "senha" => !isset($dados['senha']) ? $admin->getSenha() : $dados['senha'],
            ];
            try {
                $conexao = $this->conectar();

                $sql = sprintf("UPDATE `admin` SET `nome`='%s', `email`=%s, `senha`='%s' WHERE `codigo`=%d",
                    $dados_alt["nome"], $dados_alt["email"], $admin->getCodigo());

                $conexao->query($sql);

                if($conexao->affected_rows > 0){
                    return $this->selecionar($dados["codigo"]);
                } else {
                    $conexao->close();
                    return false;
                }
                $conexao->close();
            }catch (\Exception $e){
                throw new Exception();
            }
        }

        public function listar($pagina, $quantidade, $busca){
            $conexao = $this->conectar();
            
            $pagina = $pagina * $quantidade - $quantidade;
            
            if($busca != null){
                $resultado = $conexao->query("SELECT * FROM admin WHERE nome like '%$busca%' ORDER BY nome LIMIT $pagina, $quantidade");
            } else {
                $resultado = $conexao->query("SELECT * FROM admin ORDER BY nome LIMIT $pagina, $quantidade");
            }
            
            if($resultado){
                $lista = array();
                
                while ($registro = $resultado->fetch_array(MYSQLI_ASSOC)){
                    $item = new Admin();
                    
                    $item->setCodigo($registro["codigo"]);
                    $item->setNome($registro["nome"]);
                    $item->setEmail($registro["email"]);
                    $item->setSenha($registro["senha"]);
                 
                    array_push($lista, $item);
                }
                return $lista;
            }
            
            $conexao->close();
        }
        
        function quantidadeAdmins($busca) {
            $conexao = $this->conectar();
            
            if($busca != null){
                $resultado = $conexao->query("SELECT count(codigo) AS total FROM admin WHERE and nome like '%$busca%'");
            } else {
                $resultado = $conexao->query("SELECT count(codigo) AS total FROM admin");                
            }
            
            if ($resultado){

                if($registro = $resultado->fetch_array(MYSQLI_ASSOC)){
                    return $registro['total'];
                }
            }

            $conexao->close();

            return null; 
        }
                
        function selecionar($codigo) {
            $conexao = $this->conectar();

            $resultado = $conexao->query("SELECT * FROM admin WHERE codigo = $codigo");

            if ($resultado){

                if($registro = $resultado->fetch_array(MYSQLI_ASSOC)){
                    $item = new Admin();
                    
                    $item->setCodigo($registro["codigo"]);
                    $item->setNome($registro["nome"]);
                    $item->setEmail($registro["email"]);
                    $item->setSenha($registro["senha"]);
                    
                    return $item;
                }
            }

            $conexao->close();

            return null; 
        }   
    }    
?>