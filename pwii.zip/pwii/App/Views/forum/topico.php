<div class="container">
	<div class="row">
		<div class="col s12 m7">
			<h5>T&oacute;pico: Como dar commit no GitHub</h5>
			<p>Profª B a Bá - Portugu&eacute;s: O que &eacute; GitHub?</p>
			<p>Zim: Aperta o bot&atilde;o azul. Mas antes up os arquivos</p>
			<p>Eu: N&atilde;o esquece de logar primeiro <a>Editar:</a></p>
			<div class="input-field">
				<input placeholder="Coment&aacute;rio" type="text" class="validate">
			</div>
			<div class="input-field col s12">
				<a class="waves-effect waves-light btn right">Responder</a>
			</div>
			<h5>T&oacute;pico: Como dar commit no GitHub</h5>
			<p>Profª B a Bá - Portugu&eacute;s: O que &eacute; GitHub?</p>
			<p>Zim: Aperta o bot&atilde;o azul. Mas antes up os arquivos</p>
			<p>Eu: N&atilde;o esquece de logar primeiro <a>Editar:</a></p>
			<div class="input-field">
				<input placeholder="Coment&aacute;rio" type="text" class="validate">
			</div>
			<div class="input-field col s12">
				<a class="waves-effect waves-light btn right">Responder</a>
			</div>

		</div>
		<div class="col s12 m1"></div>
		<div class="col s12 m4">
			<h5>Avisos</h5>
			<p>Profª Lili<br>N&atilde;o Haver&aacute; Aula Quarta dia 15/05</p>
			<h5>Avisos</h5>
			<p>Profª Birl<br>Semana Academica de 22 a 25 de maio</p>
			
		</div>

	</div>
</div>