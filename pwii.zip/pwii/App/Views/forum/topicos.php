<div class="container">
	<div class="row">
		<div class="col s12 m5">
			<h4>Criar T&oacute;pico / Avisos</h4>
			<div class="input-field col s12">
				<select>
				  <option value="1">Tipo (T&oacute;pico, Aviso)</option>
				</select>
			</div>
			<div class="input-field col s12">
				<input placeholder="Titulo do T&oacute;pico" type="text" class="validate">
			</div>
			<div class="input-field col s12">
				<input placeholder="Descri&ccedil;&atilde;o" type="text" class="validate">
			</div>
			<div class="input-field col s12">
				<a class="waves-effect waves-light btn right"><i class="material-icons right">cloud</i>Salvar</a>
			</div>
			<br>
			<h5>Visualizar T&oacute;picos</h5>
			<p>T&oacute;pico: Como dar commit no GitHub <a>Responder</a></p>
			<p>T&oacute;pico: Tem aula hoje? <a>Responder</a></p>
		</div>
		<div class="col s12 m1"></div>
		<div class="col s12 m6">
			<h4>Meus T&oacute;picos / Avisos</h4>
			<p>T&oacute;pico: Com quantas faltas eu reprovo? <a>Responder</a></p>
			<p>T&oacute;pico: Quero comprar um site. Algu&eacute;m indica Wix? <a>Responder</a></p>
			
			<br>
			<h4>Editar T&oacute;pico / Avisos</h4>
			<div class="input-field col s12">
				<select>
				  <option value="1">Tipo (T&oacute;pico, Aviso)</option>
				</select>
			</div>
			<div class="input-field col s12">
				<input placeholder="Titulo do T&oacute;pico" type="text" class="validate">
			</div>
			<div class="input-field col s12">
				<input placeholder="Descri&ccedil;&atilde;o" type="text" class="validate">
			</div>
			<div class="input-field col s12">
				<a class="waves-effect waves-light btn right"><i class="material-icons right">cloud</i>Salvar</a>
			</div>
	
		</div>

	</div>
</div>