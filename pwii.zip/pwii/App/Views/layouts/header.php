<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8"/>
        <meta name="viewport" content="width=device-width, initial-scale=1"/>
        <title><?=TITLE?><?=$titulo?></title>
        <link rel="shortcut icon" type="image/png" href="<?=RECURSO?>/recursos/icone.png"/>

        <!-- CSS  -->
        <?=$css?>
        <link href="<?=RECURSO?>/css/materialize.css" type="text/css" rel="stylesheet" media="screen,projection"/>
        <link href="<?=RECURSO?>/css/estilo.css" type="text/css" rel="stylesheet" media="screen,projection"/>
        <script src="<?=RECURSO?>/js/jquery-3.2.1.js"></script>

        <?=$css?>
        <link href="https://fonts.googleapis.com/css?family=Krub" rel="stylesheet">
        <link href="<?=RECURSO?>/css/icones.css" rel="stylesheet">
    </head>
<body>
    <input value="<?=LINK?>" id="link" type="hidden"/>   
