<?php
	require_once PATH . '/App/Views/layouts/header.php';
	require_once PATH . '/App/Views/layouts/menu.php';
?>
	<br />
	<div class="container">
		<h1><?php echo $varMessage; ?><h1>
	<br />
	<br />
			<a href="http://<?php echo APP_HOST; ?>/" class="btn btn-primary btn-block btn-lg">Voltar ao início</a>
	</div>
<?php
	require_once PATH . '/App/Views/layouts/footer.php';
?>