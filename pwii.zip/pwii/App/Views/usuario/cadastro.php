<div class="container">
	<div class="row">
		<div class="col s12 m2"></div>
		<div class="col s12 m8">
			<h5>Cadastro</h5>
			<br>
			<div class="input-field">
				<input id="nome" placeholder="Fulano de tal" type="text" class="validate">
				<label for="nome">Nome</label>
			</div>
			<div class="input-field">
				<input id="email" placeholder="fulanodetal@gmail.com" type="email" class="validate">
				<label for="email">E-mail</label>
			</div>
			<div class="input-field">
				<input id="senha" placeholder="************" type="password" class="validate">
				<label for="senha">Senha</label>
			</div>
			<div class="input-field">
				<input id="instituicao" placeholder="IFGoiano" type="text" class="validate">
				<label for="instituicao">Instituição</label>
			</div>
			<div class="input-field">
				<select>
				  <option value="">Selecionar o tipo(Aluno, Professor, Moderador)</option>
				</select>
				<label>Materialize Select</label>
			  </div>
			  <div class="input-field col s12">
				<a class="waves-effect waves-light btn right">Cadastrar</a>
			</div>

		</div>

	</div>
</div>