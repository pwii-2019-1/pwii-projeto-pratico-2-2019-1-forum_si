<?php

namespace App\Controllers;

use App\Lib\Sessao;
use App\Models\BO\ConfiguracaoBO;

abstract class Controller{
    protected $app;
    private $viewVar;

    public function __construct($app)
    {
        $this->setViewParam('nameController',$app->getControllerName());
    }

    public function render($view, $titulo = null){
        $viewVar = $this->getViewVar();
        $Sessao  = Sessao::class;
        
        if(file_exists("./public/css/".$view.".css")){
            $css = '<link href="'.RECURSO.'/css/estilo.css" type="text/css" rel="stylesheet"/>';
            $css .= '<link href="'.RECURSO.'/css/'.$view.'.css" type="text/css" rel="stylesheet"/>';
        } else {
            $css = '<link href="'.RECURSO.'/css/estilo.css" type="text/css" rel="stylesheet"/>';
        }
        
        if(file_exists("./public/js/".$view.".js")){
            $js = RECURSO."/js/".$view.".js";
        }
        
        if(trim($titulo) != ''){
            $titulo = " | " . $titulo;
        }
        
        require_once PATH . '/App/Views/layouts/header.php';
        require_once PATH . '/App/Views/layouts/menu.php';
        require_once PATH . '/App/Views/' . $view . '.php';
        require_once PATH . '/App/Views/layouts/footer.php';
    }
    public function redirect($view)
    {
        header('Location: http://' . APP_HOST . $view);
        exit;
    }

    public function getViewVar()
    {
        return $this->viewVar;
    }

    public function setViewParam($varName, $varValue)
    {
        if ($varName != "" && $varValue != "") {
            $this->viewVar[$varName] = $varValue;
        }
    }
    
    public function valida(){
        if(!Sessao::getLogado()){
            Sessao::gravaMensagem('Acesso negado! Você não tem permissão para acessar essa página!');
            Sessao::setAdmin(null);
            Sessao::logado(false);
            $this->redirect('/home/login');
            exit();
        } else {
            header("Refresh:600; url=".LINK."/admin/sair");
        }
    }
    
    public function upload($file, $nome, $local){
        $tmp_nome = $file['tmp_name'];
        $nomeFile = $file['name'];

        move_uploaded_file($tmp_nome, $local . $nome);

        if(file_exists($local . $nome)){
            return true;
        }

        return false;
    }
}