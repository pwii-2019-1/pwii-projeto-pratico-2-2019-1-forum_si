<?php

namespace App\Controllers;

use App\Lib\Sessao;


class HomeController extends Controller{
    public function index(){
        
        $this->render('home/index');
    }

	public function login(){
		Sessao::gravaMensagem("Exemplo de mensagem!");            
		
        $this->render('home/login', "Login");
    }
}