<?php

namespace App\Controllers;

use App\Lib\Sessao;


class ForumController extends Controller{
    public function topicos(){
        
        $this->render('forum/topicos');
    }

	public function topico(){
        
        $this->render('forum/topico');
    }
}