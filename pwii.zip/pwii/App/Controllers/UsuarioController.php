<?php

namespace App\Controllers;

use App\Lib\Sessao;


class UsuarioController extends Controller{
	public function perfil(){

		$this->render('usuario/perfil');
    }

	public function cadastro(){

		$this->render('usuario/cadastro');
    }
}